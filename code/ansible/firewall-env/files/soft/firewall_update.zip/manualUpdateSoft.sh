#!/usr/bin/env bash
currPath=$(readlink -f .)

echo -e "Firewall手动更新安装包"

CP="/bin/cp -fr"
TargetOriginPath="/opt/netvine/origin"
TargetPath="/opt/firewall"

webDirName="frontend"
serverDirName="backend"
engineDirName="ips"

mkdir -p $TargetPath
mkdir -p $TargetPath/$webDirName
mkdir -p $TargetPath/$serverDirName
mkdir -p $TargetPath/$engineDirName

# 更新web
webPath=$currPath/$webDirName
if [ ! -d "$webPath" ]; then
    echo "$webPath 目录不存在!"
fi

webTargetPath=$TargetPath/$webDirName
rm -fr $webTargetPath/*
$CP $webPath/* $webTargetPath

supervisorctl restart fw-web

# 更新server
serverPath=$currPath/$serverDirName
if [ ! -d "$serverPath" ]; then
    echo "$serverPath 目录不存在!"
fi

serverTargetPath=$TargetPath/$serverDirName
rm -fr $serverTargetPath/*
$CP $serverPath/* $serverTargetPath

dataFirewall="/data/firewall"
if [ ! -d "$dataFirewall" ]; then
    mkdir -p dataFirewall
fi

# 存放设备目录
deviceInfo="device_info.conf"
rm -rf $dataFirewall/$deviceInfo
$CP $serverPath/resource/$deviceInfo $dataFirewall

versionInfo="version_info.conf"
rm -rf $dataFirewall/$versionInfo
$CP $serverPath/resource/$versionInfo $dataFirewall

# 更新到根目录
$CP $serverPath/resource/$versionInfo $TargetPath

supervisorctl restart fw-server

# 更新engine
enginePath=$currPath/$engineDirName
if [ ! -d "$enginePath" ]; then
    echo "$enginePath 目录不存在!"
fi

engineTargetPath=$TargetPath/$engineDirName
rm -fr $engineTargetPath/*
$CP $enginePath/* $engineTargetPath
ln -sf $engineTargetPath/lib/libhtp.so.2.0.0 $engineTargetPath/lib/libhtp.so.2
ln -sf $engineTargetPath/lib/libhtp.so.2.0.0 $engineTargetPath/lib/libhtp.so
ln -sf $engineTargetPath/bin/vtysh /usr/bin/vtysh
ldconfig

supervisorctl restart fw-engine

echo -e "Firewall手动更新安装包 Done!!"
