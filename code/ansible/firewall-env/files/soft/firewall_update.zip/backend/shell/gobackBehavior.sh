#! /bin/bash
/usr/local/mysql/bin/mysql -h localhost -uroot  -proot < /opt/netvine/$1/behavior-upgrade.sql
rm -rf /data/rules/signature-dpi/deep_behavior.rules
ln -s /opt/netvine/$1/deep_behavior.rules /data/rules/signature-dpi/