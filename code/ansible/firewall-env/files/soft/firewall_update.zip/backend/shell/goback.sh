#! /bin/bash
/usr/local/mysql/bin/mysql -h localhost -uroot  -proot < /opt/netvine/$1/sql/netvine-goback.sql
rm -rf /opt/firewall/backend /opt/firewall/ips /opt/firewall/frontend
ln -s /opt/netvine/$2/backend/ /opt/firewall/backend
ln -s /opt/netvine/$2/frontend/ /opt/firewall/frontend
ln -s /opt/netvine/$2/ips/ /opt/firewall/ips
#rm -rf /usr/local/nginx/html/assets /usr/local/nginx/html/favicon.ico /usr/local/nginx/html/index.html /usr/local/nginx/html/logo.ico /usr/local/nginx/html/js
#cp -R /opt/firewall/frontend/assets /usr/local/nginx/html/
#cp -R /opt/firewall/frontend/favicon.ico /usr/local/nginx/html/
#cp -R /opt/firewall/frontend/index.html /usr/local/nginx/html/
#cp -R /opt/firewall/frontend/logo.ico /usr/local/nginx/html/
#cp -R /opt/firewall/frontend/js /usr/local/nginx/html/