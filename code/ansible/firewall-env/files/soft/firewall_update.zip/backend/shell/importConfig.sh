#! /bin/bash
if [ $1 == "import" ];then
  cd ./resource/config/
  rm -rf ./系统配置.json ./网络攻击.json ./db.sql ./systemconfig.zip  ./rules
elif [ $1 == "unzip" ];then
  cd ./resource/config/
  unzip systemconfig.zip -d ./
elif [ $1 == "sql" ];then
  cd ./resource/config/
  /usr/local/mysql/bin/mysql -uroot -pNetvine123#@! audit <./db.sql
fi