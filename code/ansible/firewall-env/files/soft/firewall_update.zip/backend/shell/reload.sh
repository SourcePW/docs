#! /bin/bash

#1. 判断参数个数
if [ $1 = "change" ]
then
   vtysh -c "configure terminal" -c dpi -c "dpi engine-reload"
   echo "开启"
else
   echo "结束"
fi