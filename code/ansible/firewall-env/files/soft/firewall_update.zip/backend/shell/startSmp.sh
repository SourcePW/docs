cd /opt/watcher
if [ $1 == "restart" ];then
  sh restart.sh
elif [ $1 == "state" ];then
  ./watcher $1
else
  ./watcher connect -s $1
fi