#!/bin/bash

model=$1
action=$2

echo "vtysh args=$@"

if [ $model = "whitelist" ]; then
    if [ $action = "add" ]; then
        rule=$3
        vtysh -c "configure terminal" -c firewall -c "firewall rule whitelist add $rule"
        echo "增加白名单$rule"
    elif [ $action = "del" ]; then
        vtysh -c "configure terminal" -c firewall -c "firewall rule whitelist del"
        echo "删除白名单"
    elif [ $action = "study" ]; then
        flag=$3
        if [ $3 = "on" ]
        then
           vtysh -c "configure terminal" -c dpi -c "dpi self-acquire-switch on $4"
           echo "开启学习"
        else
           vtysh -c "configure terminal" -c dpi -c "dpi self-acquire-switch off $4"
           echo "结束学习"
        fi
    elif [ $action = "outside" ]; then
        flag=$3
        if [ $3 = "query" ]
        then
           vtysh -c "configure terminal" -c dpi -c "show dpi whitelist default rule"
           echo "查看未匹配白名单动作"
        else
           vtysh -c "configure terminal" -c dpi -c "dpi whitelist default $4"
           echo "修改未匹配白名单动作"
        fi
    fi
elif [ $model = "blacklist" ]; then
    if [ $action = "add" ]; then
        rule=$3
        vtysh -c "configure terminal" -c firewall -c "firewall rule blacklist add $rule"
        echo "增加黑名单$rule"
    elif [ $action = "del" ]; then
        vtysh -c "configure terminal" -c firewall -c "firewall rule blacklist del"
        echo "删除白名单"
    fi
elif [ $model = "suricata" ]; then
    if [ $action = "reload" ]; then
        vtysh -c "configure terminal" -c firewall -c "firewall rule reload"
        echo "规则重载"
    fi
elif [ $model = "behavior" ]; then
    if [ $action = "protocol" ]; then
        vtysh -c "configure terminal" -c dpi -c "dpi add-protocol identify $3"
        echo "协议改动$3"
    elif [ $action = "preProtocol" ]; then
        vtysh -c "configure terminal" -c dpi -c "dpi set_protocol_switch $3"
        echo "预定义协议改动$3"
    elif [ $action = "verdict" ]; then
        vtysh -c "configure terminal" -c dpi -c "dpi add-protocol identify verdict $3"
    fi
fi
