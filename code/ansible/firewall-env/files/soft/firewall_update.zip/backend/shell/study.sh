#! /bin/bash

#1. 判断参数个数
if [ $1 = "on" ]
then
   vtysh -c "configure terminal" -c dpi -c "dpi self-acquire-switch on $2"
   echo "开启"
else
   vtysh -c "configure terminal" -c dpi -c "dpi self-acquire-switch off $2"
   echo "结束"
fi