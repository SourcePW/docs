#! /bin/bash
log_file=/data/logs/fw-server/upgrade.log
echo "$@" >> $log_file
if [ $3 == "import" ];then
  unzip $1 -d /root/netvine/
  mkdir /opt/netvine/$2/
  cp -r /root/netvine/* /opt/netvine/$2/
  rm -rf /root/netvine/
elif [ $3 == "action" ];then
  echo "start-upgrade -- " >> $log_file
  rm -rf  /opt/firewall/backend /opt/firewall/ips /opt/firewall/frontend /opt/firewall/version_info.conf
  ln -s /opt/netvine/$2/backend/ /opt/firewall/backend
  ln -s /opt/netvine/$2/frontend/ /opt/firewall/frontend
  ln -s /opt/netvine/$2/ips/ /opt/firewall/ips
  ln -s /opt/netvine/$2/version_info.conf /opt/firewall/

  echo "exec-sql-file upgrade -- " >> $log_file
  (/usr/local/mysql/bin/mysql -h localhost -uroot  -proot --force -D firewall < /opt/firewall/backend/sql/firewall_ddl_v1.1.sql) >> $log_file 2>&1
  echo "stop-upgrade -- " >> $log_file
fi
exit 0