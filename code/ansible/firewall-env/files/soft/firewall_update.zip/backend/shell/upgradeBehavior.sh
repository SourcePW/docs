#! /bin/bash
if [ $3 == "import" ];then
  unzip $1 -d /root/netvine/
  mkdir /opt/netvine/$2/
  cp -r /root/netvine/* /opt/netvine/$2/
  rm -rf /root/netvine/
elif [ $3 == "action" ];then
  /usr/local/mysql/bin/mysql -h localhost -uroot  -proot < /opt/netvine/$2/behavior-upgrade.sql
  rm -rf /data/firewall/ips/rules/netvine_engine/behavior_detection.rules
  ln -s /opt/netvine/$2/behavior_detection.rules /data/firewall/ips/rules/netvine_engine/
fi
exit 0