#! /bin/bash
/usr/local/mysql/bin/mysql -h localhost -uroot  -proot < /opt/netvine/$1/blacklist-upgrade.sql
rm -rf /data/rules/signature-dpi/blacklist.rules
ln -s /opt/netvine/$1/blacklist.rules /data/rules/signature-dpi/