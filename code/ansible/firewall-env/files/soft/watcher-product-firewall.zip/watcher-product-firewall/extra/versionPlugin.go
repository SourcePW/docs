package extra

//go:generate go install github.com/traefik/yaegi/cmd/yaegi@v0.10.0
//go:generate yaegi extract .././extra
//go:generate yaegi extract .././ctx
//go:generate yaegi extract github.com/fsnotify/fsnotify
//go:generate yaegi extract github.com/vulcand/oxy/testutils

import (
	"fmt"
	"go-admin-sdks/ctx"
	"os"
	"strings"
)

func GetVersion(ctx *ctx.PluginCtx) (v interface{}, err error) {
	fmt.Println("GetVersion")
	versionTxtPath := ctx.InitParam.InitParam["version"].(string)
	fmt.Println("verpath:" + versionTxtPath)
	content, err := os.ReadFile(versionTxtPath)
	if err != nil {
		panic(err)
	}

	version := strings.ReplaceAll(string(content), "version=", "")
	//去除空白字符
	version = strings.TrimSpace(version)
	return version, nil
}

func InitVersion(ictx *ctx.InitCtx) (v interface{}, err error) {

	return "", nil
}
