package extra

//go:generate go install github.com/traefik/yaegi/cmd/yaegi@v0.10.0
//go:generate yaegi extract .././extra
//go:generate yaegi extract .././ctx
//go:generate yaegi extract github.com/fsnotify/fsnotify
//go:generate yaegi extract github.com/vulcand/oxy/testutils

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/vulcand/oxy/testutils"
	"go-admin-sdks/ctx"
	"os"
	"strconv"
	"strings"
	"time"
)

//func  PreRequest ( ctx *PluginCtx){
//	ctx.Request.Header.Add("x-token","yyyyyyyyyyyyy")
//	fmt.Print("--------PreRequest----------")
//}

func OnBiz(ctx *ctx.PluginCtx) (v interface{}, err error) {
	//ctx.Request.Header.Set("x-token", "eeeeeeeeeeeeeee")
	//fmt.Println("OnBiz")
	filePath := "head.txt"
	//ctx.InitParam["xxx"] = "yyyyy"
	m := make(map[string]string)
	content2Map(filePath, &m)
	//fmt.Println(" 测试自动安装444")
	uri := ctx.Request.RequestURI
	unixtime := time.Now().Unix()
	tmp := ""
	if strings.Index(uri, "?") < 0 {
		tmp += "?"
	} else {
		tmp += "&"
	}
	tmp += "_=" + strconv.FormatInt(unixtime, 10)
	csrf_token, isok := m["csrf_token"]
	if isok {
		tmp += "&csrf_token=" + csrf_token
		delete(m, "csrf_token")
	}
	uri += tmp
	ctx.Request.RequestURI = uri
	ctx.Request.URL = testutils.ParseURI(ctx.Request.URL.Scheme + "://" + ctx.Request.URL.Host + uri)
	//ctx.Request.Form.Add("csrf_token",csrf_token)
	//_=1652842936241&csrf_token=ImIxZTZjMTY4YjU3YWQ2ZDdiNzFmNGVjMjQzMGMxZDlmMzU4ZjUwZDgi.FWXzNA.ZDHKboZWzWI6jXpuZjXEnyrEaJ8
	ctx.Request.Header.Del("Authorization")
	ctx.Request.Header.Del("x-token")
	for key, val := range m {
		//fmt.Printf("k:%s,v:%s",key,val)
		//ctx.Request.Header.Set(key, val)
		ctx.Request.Header[key] = []string{val}
	}
	return "", nil
}

//按第一个出现分隔符的位置截取成两段
func splitBySubStr(str, separator string) (headStr, tailStr string, err error) {
	index := strings.Index(str, separator)
	if index < 0 {
		return "", "", errors.New("separator not exists")
	}
	return str[:index], str[index+1:], nil
}

func content2Map(filepath string, dict *map[string]string) {
	b, err := os.ReadFile(filepath)
	if err != nil {
		panic(err)
	}
	err = json.Unmarshal(b, dict)
	if err != nil {
		panic(err)
	}

}
func OnInit(ictx *ctx.InitCtx) (v interface{}, err error) {
	//filePath:="head.txt"
	//ctx.InitParam["xxx"] = "yyyyy"
	//content2Map(filePath,&ictx.InitParam)
	//fmt.Println("oninit")
	//
	//   fmt.Println("进入外层协程")
	//	watcher, err := fsnotify.NewWatcher()
	//	if err != nil {
	//		log.Fatal(err)
	//	}
	//	defer watcher.Close()
	//	done := make(chan bool)
	//	go func() {
	//		fmt.Println("进入内层协程")
	//
	//		for {
	//			select {
	//			case event, ok := <-watcher.Events:
	//				if !ok {
	//					return
	//				}
	//				fmt.Println("event:", event)
	//				if event.Op&fsnotify.Write == fsnotify.Write {
	//					fmt.Println("modified file:", event.Name)
	//					content2Map(filePath,&ictx.InitParam)
	//				}
	//			case err, ok := <-watcher.Errors:
	//				if !ok {
	//					return
	//				}
	//				fmt.Println("error:", err)
	//			}
	//		}
	//	}()
	//	err = watcher.Add(filePath)
	//	if err != nil {
	//		fmt.Println(err)
	//	}
	//	<-done
	//watcher := ctx.FileWatcher{filePath, func(s string) {
	//	content2Map(filePath, &ictx.InitParam)
	//}}
	//watcher.Watch()
	return "", nil
}
func GetVersion2(ctx *ctx.PluginCtx) (v interface{}, err error) {
	fmt.Println("getVersion2")
	return "", nil
}
