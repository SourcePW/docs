#!/bin/bash
 
# 从命令行读取进程名称
NAME="watcher"  

echo "---------------"

echo 'killing ->' $NAME  

# 过滤进程列表，不显示grep对应的进程，awk从第二列获取进程ID
ID=`ps -ef | grep "$NAME" | grep -v "grep" | awk '{print $2}'`

echo 'found ID list:' $ID
for id in $ID
    do
    # 杀掉进程
    kill  $id
    echo "killed $id"
    done

echo "---------------"
auditVersionConf="/opt/audit/version_info.conf"
auditDeviceConf="/data/audit/device_info.conf"
watcherConf="/opt/watcher/config/settings.yml"
if [ -f $auditVersionConf ]; then
    version=$(grep -e "version=" $auditVersionConf)
    echo $version > /opt/watcher/config/version.txt
    echo "update version info $version"
fi

if [ -f $auditDeviceConf ]; then

    snInfo=$(grep -e "sn=" $auditDeviceConf)
    echo ${snInfo#*sn=} > /opt/watcher/config/baseboard.txt

    mnInfo=$(grep -e "mn=" $auditDeviceConf)
    # EquipmentModel: "1U"
    sed -i "s/EquipmentModel: \"\w*\"/EquipmentModel: \"${mnInfo#*mn=}\"/g" $watcherConf
    echo "update device info sn=$snInfo mn=$mnInfo"
fi
cd /opt/watcher 
chmod +x watcher
nohup ./watcher server -c /opt/watcher/config/settings.yml &
