#### watcher部署配置

产品定制化配置

为不同产品类型的watcher提供各自的部署配置，包括用于项目的settings.yml文件，用于获取登录授权的head.txt,定制化插件包等。

