#!/bin/bash
 
# 从命令行读取进程名称
NAME="watcher"  

echo "---------------"

echo 'killing ->' $NAME  

# 过滤进程列表，不显示grep对应的进程，awk从第二列获取进程ID
ID=`ps -ef | grep "$NAME" | grep -v "grep" | awk '{print $2}'`

echo 'found ID list:' $ID
for id in $ID
    do
    # 杀掉进程
    kill  $id
    echo "killed $id"
    done

echo "---------------"
